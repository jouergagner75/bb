# Backbase Project 

This project is created by http://start.backbase.com 

## README files

- [Backbase 6 :: Platform](platform/README.md)
- [CX 6.1 series](cx6-targeting/README.md)
- [Backbase 6 :: DBS](dbs/README.md)
- [Backbase 6 :: Statics](statics/README.md)
