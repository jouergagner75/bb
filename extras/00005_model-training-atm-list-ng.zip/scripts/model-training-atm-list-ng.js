(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(require("vendor-bb-angular"), require("data-bb-locations-http-ng"));
	else if(typeof define === 'function' && define.amd)
		define("model-training-atm-list-ng", ["vendor-bb-angular", "data-bb-locations-http-ng"], factory);
	else if(typeof exports === 'object')
		exports["model-training-atm-list-ng"] = factory(require("vendor-bb-angular"), require("data-bb-locations-http-ng"));
	else
		root["model-training-atm-list-ng"] = factory(root["vendor-bb-angular"], root["data-bb-locations-http-ng"]);
})(this, function(__WEBPACK_EXTERNAL_MODULE_3__, __WEBPACK_EXTERNAL_MODULE_13__) {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__(11);

/***/ }),
/* 1 */,
/* 2 */,
/* 3 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_3__;

/***/ }),
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.modelAtmListKey = undefined;
	
	var _vendorBbAngular = __webpack_require__(3);
	
	var _vendorBbAngular2 = _interopRequireDefault(_vendorBbAngular);
	
	var _atmList = __webpack_require__(12);
	
	var _atmList2 = _interopRequireDefault(_atmList);
	
	var _dataBbLocationsHttpNg = __webpack_require__(13);
	
	var _dataBbLocationsHttpNg2 = _interopRequireDefault(_dataBbLocationsHttpNg);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	/**
	 * @module model-training-atm-list-ng
	 *
	 * @description
	 * Model for widget-training-atm-list-ng
	 *
	 * @example
	 * import modelAtmListModuleKey, { modelAtmListKey } from 'model-training-atm-list-ng';
	 *
	 * angular
	 *   .module('ExampleModule', [
	 *     modelAtmListModuleKey,
	 *   ])
	 *   .factory('someFactory', [
	 *     modelAtmListKey,
	 *     // into
	 *     function someFactory(atmListModel) {
	 *       // ...
	 *     },
	 *   ]);
	 */
	var moduleKey = 'model-training-atm-list-ng';
	var modelAtmListKey = exports.modelAtmListKey = moduleKey + ':model';
	
	exports.default = _vendorBbAngular2.default.module(moduleKey, [_dataBbLocationsHttpNg2.default]).factory(modelAtmListKey, ['$q', _dataBbLocationsHttpNg.locationsDataKey,
	/* into */
	_atmList2.default]).name;

/***/ }),
/* 12 */
/***/ (function(module, exports) {

	"use strict";
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.default = atmListModel;
	/**
	 * Model factory for model-training-atm-list-ng
	 *
	 * @inner
	 * @type {function}
	 * @param {Object} Promise An ES2015 compatible `Promise` object.
	 *
	 * @return {Object}
	 */
	function atmListModel(Promise, LocationsData) {
	  /**
	   * @name atmListModel#load
	   * @type {function}
	   *
	   * @description
	   * Load some data.
	   *
	   * @returns {Promise.<Object>} A Promise with some data.
	   */
	  function loadAtmLocations() {
	    return LocationsData.getLocations().then(function (response) {
	      return response.data;
	    });
	  }
	
	  /**
	   * @name atmListModel#save
	   * @type {function}
	   *
	   * @description
	   * Save some data.
	   *
	   * @returns {Promise.<Object>} A Promise with some data.
	   */
	  function save() {
	    return Promise.resolve();
	  }
	
	  /**
	   * @name atmListModel
	   * @type {Object}
	   */
	  return {
	    loadAtmLocations: loadAtmLocations,
	    save: save
	  };
	}

/***/ }),
/* 13 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_13__;

/***/ })
/******/ ])
});
;
//# sourceMappingURL=model-training-atm-list-ng.js.map