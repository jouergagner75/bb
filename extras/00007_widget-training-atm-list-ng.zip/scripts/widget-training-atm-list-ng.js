(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory(require("vendor-bb-angular"), require("lib-bb-widget-ng"), require("lib-bb-event-bus-ng"), require("lib-bb-widget-extension-ng"), require("model-training-atm-list-ng"), require("lib-bb-model-errors"));
	else if(typeof define === 'function' && define.amd)
		define("widget-training-atm-list-ng", ["vendor-bb-angular", "lib-bb-widget-ng", "lib-bb-event-bus-ng", "lib-bb-widget-extension-ng", "model-training-atm-list-ng", "lib-bb-model-errors"], factory);
	else if(typeof exports === 'object')
		exports["widget-training-atm-list-ng"] = factory(require("vendor-bb-angular"), require("lib-bb-widget-ng"), require("lib-bb-event-bus-ng"), require("lib-bb-widget-extension-ng"), require("model-training-atm-list-ng"), require("lib-bb-model-errors"));
	else
		root["widget-training-atm-list-ng"] = factory(root["vendor-bb-angular"], root["lib-bb-widget-ng"], root["lib-bb-event-bus-ng"], root["lib-bb-widget-extension-ng"], root["model-training-atm-list-ng"], root["lib-bb-model-errors"]);
})(this, function(__WEBPACK_EXTERNAL_MODULE_3__, __WEBPACK_EXTERNAL_MODULE_15__, __WEBPACK_EXTERNAL_MODULE_16__, __WEBPACK_EXTERNAL_MODULE_17__, __WEBPACK_EXTERNAL_MODULE_21__, __WEBPACK_EXTERNAL_MODULE_23__) {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__(20);

/***/ }),
/* 1 */,
/* 2 */,
/* 3 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_3__;

/***/ }),
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */,
/* 15 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_15__;

/***/ }),
/* 16 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_16__;

/***/ }),
/* 17 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_17__;

/***/ }),
/* 18 */,
/* 19 */,
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var _vendorBbAngular = __webpack_require__(3);
	
	var _vendorBbAngular2 = _interopRequireDefault(_vendorBbAngular);
	
	var _libBbWidgetNg = __webpack_require__(15);
	
	var _libBbWidgetNg2 = _interopRequireDefault(_libBbWidgetNg);
	
	var _libBbEventBusNg = __webpack_require__(16);
	
	var _libBbEventBusNg2 = _interopRequireDefault(_libBbEventBusNg);
	
	var _libBbWidgetExtensionNg = __webpack_require__(17);
	
	var _libBbWidgetExtensionNg2 = _interopRequireDefault(_libBbWidgetExtensionNg);
	
	var _modelTrainingAtmListNg = __webpack_require__(21);
	
	var _modelTrainingAtmListNg2 = _interopRequireDefault(_modelTrainingAtmListNg);
	
	var _controller = __webpack_require__(22);
	
	var _controller2 = _interopRequireDefault(_controller);
	
	var _defaultHooks = __webpack_require__(24);
	
	var _defaultHooks2 = _interopRequireDefault(_defaultHooks);
	
	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
	
	var moduleKey = 'widget-training-atm-list-ng'; /**
	                                                * @module widget-training-atm-list-ng
	                                                *
	                                                * @description
	                                                * Atm list
	                                                */
	
	var hooksKey = moduleKey + ':hooks';
	
	exports.default = _vendorBbAngular2.default.module(moduleKey, [_libBbWidgetNg2.default, _libBbEventBusNg2.default, _modelTrainingAtmListNg2.default]).factory(hooksKey, (0, _libBbWidgetExtensionNg2.default)(_defaultHooks2.default)).controller('AtmListController', [
	// dependencies to inject
	_libBbEventBusNg.eventBusKey, hooksKey, _libBbWidgetNg.widgetKey, _modelTrainingAtmListNg.modelAtmListKey,
	/* into */
	_controller2.default]).name;

/***/ }),
/* 21 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_21__;

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.default = AtmListController;
	
	var _libBbModelErrors = __webpack_require__(23);
	
	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } /**
	                                                                                                                                                                                                                   * @module widget-training-atm-list-ng
	                                                                                                                                                                                                                   * @name AtmListController
	                                                                                                                                                                                                                   *
	                                                                                                                                                                                                                   * @description
	                                                                                                                                                                                                                   * Atm list
	                                                                                                                                                                                                                   */
	
	var errorMessage = function errorMessage(code) {
	  var _E_AUTH$E_CONNECTIVIT;
	
	  return (_E_AUTH$E_CONNECTIVIT = {}, _defineProperty(_E_AUTH$E_CONNECTIVIT, _libBbModelErrors.E_AUTH, 'error.load.auth'), _defineProperty(_E_AUTH$E_CONNECTIVIT, _libBbModelErrors.E_CONNECTIVITY, 'error.load.connectivity'), _E_AUTH$E_CONNECTIVIT)[code] || 'error.load.unexpected';
	};
	
	function AtmListController(bus, hooks, widget, model) {
	  var $ctrl = this;
	
	  $ctrl.atms = [];
	
	  /**
	   * AngularJS Lifecycle hook used to initialize the controller
	   *
	   * @name AtmListController#$onInit
	   * @type {function}
	   * @returns {void}
	   */
	  var $onInit = function $onInit() {
	    $ctrl.isLoading = true;
	
	    $ctrl.amountOfAtmsShown = widget.getLongPreference('amountOfAtmsShown');
	    $ctrl.showViewAddressButton = widget.getBooleanPreference('showViewAddressButton');
	
	    // Method to load atms
	    model.loadAtmLocations().then(function (data) {
	      // Once data is loaded, assign it to atms
	      $ctrl.atms = data.locations;
	    });
	
	    bus.publish('cxp.item.loaded', {
	      id: widget.getId()
	    });
	
	    bus.publish('bb.item.loaded', {
	      id: widget.getId()
	    });
	  };
	
	  var viewAtmDetails = function viewAtmDetails(atm) {
	    // TODO: 1. Publish a custom event for atm selection and pass the data of selected atm
	    bus.publish('training.event.view.atm.details', atm);
	  };
	
	  Object.assign($ctrl, {
	    $onInit: $onInit,
	    viewAtmDetails: viewAtmDetails,
	
	    /**
	     * @description
	     * The value returned from {@link Hooks.processItems} hook.
	     * null if the items aren't loaded.
	     *
	     * @name AtmListController#items
	     * @type {any}
	     */
	    items: null,
	
	    /**
	     * @description
	     * Loading status
	     *
	     * @name AtmListController#isLoading
	     * @type {boolean}
	     */
	    isLoading: false,
	
	    /**
	     * @description
	     * The error encountered when attempting to fetch from the model
	     *
	     * @name AtmListController#error
	     * @type {ModelError}
	     */
	    error: null
	
	  });
	}

/***/ }),
/* 23 */
/***/ (function(module, exports) {

	module.exports = __WEBPACK_EXTERNAL_MODULE_23__;

/***/ }),
/* 24 */
/***/ (function(module, exports) {

	"use strict";
	
	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	
	var identity = function identity(a) {
	  return a;
	};
	
	exports.default = {
	  itemsFromModel: identity
	};

/***/ })
/******/ ])
});
;
//# sourceMappingURL=widget-training-atm-list-ng.js.map